﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace question_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j;
            int[,] arr1 = new int[3, 3];

            Console.WriteLine("Input elements in the matrix :");
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    arr1[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("The matrix is : ");
            for (i = 0; i < 3; i++)
            {
                Console.WriteLine("\n");
                for (j = 0; j < 3; j++)
                    Console.Write("", arr1[i, j]);
            }
            Console.WriteLine("");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace quesion_2
{
    class Program
    {
        static void Main(string[] args)
        {
            
  Console.WriteLine("Input the number of elements to be stored in the array: ");
            
            int[] arr = { 5, 15, 5 };
            int size = arr.Length; 

           for (int i = 0; i < size; i++)
            {

             bool isUnique = true;

                for (int j = 0 ; j < size; j++)
                {



                    if (arr[i] == arr[j])
                    {

                        isUnique = false;
                        break;
                    }
              
                   else { Console.WriteLine("Unique element:" + arr[i]); }
                }
            }


           
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace question1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = { 10, 15, 20 };
            int output = a.Sum();
            Console.WriteLine("Sum of all elements is:" + output);

           
        }
    }


}
    


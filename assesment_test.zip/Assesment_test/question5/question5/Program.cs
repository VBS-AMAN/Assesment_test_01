﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace question5
{
    class Program
    {
        static void Main(string[] args)
        {
			int n;
			n = 723;
			Console.WriteLine("converted roman numerals value: ")
			Console.WriteLine(convertIntoRoman(n))
		}
		public static string convertIntoRoman(int value)
		{
			if (value < 1) return string.Empty;
			if (value >= 1000) return "M" + convertIntoRoman(value - 1000);
			if (value >= 900) return "CM" + convertIntoRoman(value - 900);
			if (value >= 500) return "D" + convertIntoRoman(value - 500);
			if (value >= 400) return "CD" + convertIntoRoman(value - 400);
			if (value >= 100) return "C" + convertIntoRoman(value - 100);
			if (value >= 90) return "XC" + convertIntoRoman(value - 90);
			if (value >= 50) return "L" + convertIntoRoman(value - 50);
			if (value >= 40) return "XL" + convertIntoRoman(value - 40);
			if (value >= 10) return "X" + convertIntoRoman(value - 10);
			if (value >= 9) return "IX" + convertIntoRoman(value - 9);
			if (value >= 5) return "V" + convertIntoRoman(value - 5);
			if (value >= 4) return "IV" + convertIntoRoman(value - 4);
			if (value >= 1) return "I" + convertIntoRoman(value - 1);
		}

	}
	

    return 0;
}

        
    

